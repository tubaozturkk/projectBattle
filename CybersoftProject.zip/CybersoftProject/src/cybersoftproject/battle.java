package cybersoftproject;

import cybersoftproject.properties.Bug;
import cybersoftproject.properties.Hero;
import cybersoftproject.properties.Lion;
import cybersoftproject.properties.Mutant;
import cybersoftproject.properties.Zombie;
import cybersoftproject.properties.ZombieDog;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.TreeSet;

/**
 *
 * @author Tugba.Ozturk
 */
public class battle { 
    File.ReadFile rf = new File.ReadFile();
    public int resourceloc = rf.findvalue("are", "Resources", "meters");
    Hero myHero=  myHero(); 
    Bug myBug=  myBug(); 
    Lion myLion = new Lion();
    Zombie myZombie = new Zombie();
    Mutant myMutant = new Mutant();
    ZombieDog myZombieDog = new ZombieDog();
    TreeSet<NameAndLoc> set=new TreeSet<NameAndLoc>(); 
    public List<String>  battle() //savaşı başlattığım metod sonuçları liste olarak döndürür.
    {       
        createTreeSet();
        //TreeSet<NameAndLoc> tset = new TreeSet<>(set); //
        List<String> output = new ArrayList<String>();
        output.add("Hero started journey with  "+ myHero.hp+" HP! ");
        boolean alive = true;
        int count =0;
        while(alive)
        {
            for(NameAndLoc nameandloc:set)
            {
                if(resourceloc>nameandloc.Loc)
                {
                    count++;
                    int enemyhp=0,enemyattack=0;
                
                    switch(nameandloc.Name)
                    {
                        case "Bug":
                            enemyhp = myBug.hp;
                            enemyattack = myBug.attack;
                        break;
                        case "Lion":
                            enemyhp = myLion.hp;
                            enemyattack = myLion.attack;
                        break;
                        case "Zombie":
                            enemyhp = myZombie.hp;
                            enemyattack = myZombie.attack;
                        break;
                        case "ZombieDog":
                            enemyhp = myZombieDog.hp;
                            enemyattack = myZombieDog.attack;
                        break;
                        case "Mutant":
                            enemyhp = myMutant.hp;
                            enemyattack = myMutant.attack;
                        break;
                    }
                
                    int heroattackcount  = (int) Math.ceil((float)enemyhp/(float)myHero.attack);
                    myHero.hp((enemyattack*heroattackcount));
                
                   if(myHero.hp<= 0|| count == set.size()+1)
                    {
                        if(myHero.hp>0)
                        {
                            output.add("Hero Survived!");
                            alive = false;
                            break;
                        }
                        else
                        {
                            myHero.hp =myHero.hp+(enemyattack*heroattackcount);
                            enemyhp = enemyhp- (int) Math.ceil(((float)myHero.hp/(float)enemyattack))* myHero.attack;
                      
                            output.add(nameandloc.Name +" defeated Hero with "+enemyhp+" HP remaining");
                            output.add("Hero is Dead!! Last seen at position "+nameandloc.Loc);
                            alive = false;
                       
                            break;
                        
                        }                    
                    }
                    else
                    {       
                        output.add("Hero defeated "+ nameandloc.Name+" with "+myHero.hp +" HP remaining");
                    }
                
                }
                else{break;}
               
            }
        
        }
        return output;
    }
    
    public void createTreeSet() //Treeseti doldurduğum metod
    {
          
        for(int i=0;i<myBug.locOfEnemies.size();i++)
        {
            NameAndLoc n1 = new NameAndLoc(myBug.name, myBug.locOfEnemies.get(i));
            set.add(n1);
        }
        for(int i=0;i<myLion.locOfEnemies.size();i++)
        {
            set.add(new NameAndLoc(myLion.name, myLion.locOfEnemies.get(i)));           
        }
        for(int i=0;i<myZombie.locOfEnemies.size();i++)
        {
            set.add(new NameAndLoc(myZombie.name, myZombie.locOfEnemies.get(i)));            
        }
         for(int i=0;i<myZombieDog.locOfEnemies.size();i++)
        {
            set.add(new NameAndLoc(myZombieDog.name, myZombieDog.locOfEnemies.get(i)));           
        }
         for(int i=0;i<myMutant.locOfEnemies.size();i++)
        {
            set.add(new NameAndLoc(myMutant.name, myMutant.locOfEnemies.get(i)));           
        }
    
    
    }
     public static Hero myHero() {
        //This method creates our hero

        Hero hero = new Hero();
        return hero;
    }
    public static Bug myBug() {
        //This method creates our bug

        Bug bug = new Bug();
        return bug;
    }
}
