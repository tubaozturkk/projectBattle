package cybersoftproject;
/**
 *
 * @author Tugba.Ozturk
 */

public class CybersoftProject {

    public static void main(String[] args) {
        File.WriteToFile writeToFile = new File.WriteToFile(); //class çağırma
        File.ReadFile readFile = new File.ReadFile(); //class çağırma
        readFile.readFile();        //metod çağırma
        battle b = new battle();     //metod çağırma
        writeToFile.writeFile(b.battle()); //metod çağırma
    }
   
   
}
