package cybersoftproject;

/**
 *
 * @author Tugba.Ozturk
 */
public class NameAndLoc implements Comparable{
    String Name;
    int Loc;
    public NameAndLoc(String Name,int Loc) //karakteri ve onun lokasyonlarını tutmak için oluşturduğum class. Lokasyonları order etmek için treeset kullandım bu yüzden ayrıca bu class'ı oluşturdum.
    {
        this.Name = Name;
        this.Loc = Loc;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int getLoc() {
        return Loc;
    }

    public void setLoc(int Loc) {
        this.Loc = Loc;
    }
     @Override
    public int compareTo(Object o) {
        return  (this.getLoc() < ((NameAndLoc) o).getLoc() ? -1 : (this.getLoc() == ((NameAndLoc) o).getLoc() ? 0 : 1));
    }
    
}
