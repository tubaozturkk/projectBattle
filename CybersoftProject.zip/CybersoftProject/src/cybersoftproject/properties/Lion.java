package cybersoftproject.properties;

import java.util.List;

/**
 *
 * @author Tugba.Ozturk
 */
public class Lion extends Characters implements CharacterPropertiesInterface{
    File.ReadFile rf = new File.ReadFile();
    public Lion() {
        super.name = "Lion";
        super.setAttack(rf.findvalue("is", "attack", name));
        super.setHp(rf.findvalue("has","hp",name));
        rf.findvalueLoc("position","position",name);
        super.locOfEnemies = rf.allLocLion;
    }
    @Override
    public void setName(String name) {
        super.setName(name); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getName() {
        return super.getName(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean alive() {
        return super.alive(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void hp(int a) {
        super.hp(a); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int attack() {
        return super.attack(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setLocOfEnemies(List<Integer> locOfEnemies) {
        super.setLocOfEnemies(locOfEnemies); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Integer> getLocOfEnemies() {
        return super.getLocOfEnemies(); //To change body of generated methods, choose Tools | Templates.
    }

   

    @Override
    public void setAttack(int attack) {
        super.setAttack(attack); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getAttack() {
        return super.getAttack(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setHp(int hp) {
        super.setHp(hp); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getHp() {
        return super.getHp(); //To change body of generated methods, choose Tools | Templates.
    }
    
}
