package cybersoftproject.properties;

/**
 *
 * @author Tugba.Ozturk
 */
public interface  CharacterPropertiesInterface { //classların sahip olabileceği metodları burada belirttim.
    int attack();
    void hp(int a);
    boolean alive();
    String getName();
    void setName(String name);
    
    
}
