package cybersoftproject.properties;

import java.util.List;

/**
 *
 * @author Tugba.Ozturk
 */
public abstract class Characters implements CharacterPropertiesInterface{
    public String name;
    public int hp;
    public List<Integer> locOfEnemies;
    public int attack;

    public int getAttack() {
        return attack;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public List<Integer>  getLocOfEnemies() {
        return locOfEnemies;
    }

    public void setLocOfEnemies(List<Integer>  locOfEnemies) {
        this.locOfEnemies = locOfEnemies;
    }
        
    @Override
    public int attack() {
        return attack;
    }

    @Override
    public void hp(int a) {
        hp = hp - a;
    }

    @Override
    public boolean alive() {
       return (getHp() <= 0);
    }

    @Override
    public String getName() {
        
        return name;
    }

    @Override
    public void setName(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
