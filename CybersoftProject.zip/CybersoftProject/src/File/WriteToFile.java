package File;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;
/**
 *
 * @author Tugba.Ozturk
 */

public class WriteToFile {
   public void writeFile(List<String> listOfResult)
   {
        try 
        {  
            Scanner inputObj = new Scanner(System.in);
            System.out.println("Please specify txt path for output");
            //String pathtxt = "C:\\Users\\Tugba.Ozturk\\Desktop\\output.txt";
            String pathtxt = inputObj.nextLine();
            FileWriter myWriter = new FileWriter(pathtxt);
            
            for(int i=0; i<listOfResult.size();i++)
            {
                myWriter.write(listOfResult.get(i)+"\n");
            }
            
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } 
        catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
    } 
   }
}
