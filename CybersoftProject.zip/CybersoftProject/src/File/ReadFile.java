package File;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 *
 * @author Tugba.Ozturk
 */
public class ReadFile {
    public static List<String> allLine = new ArrayList<String>();
    public static List<Integer> allLocBug= new ArrayList<Integer>();
    public static List<Integer> allLocLion= new ArrayList<Integer>();
    public static List<Integer> allLocZombie= new ArrayList<Integer>();
    public static List<Integer> allLocMutant= new ArrayList<Integer>();
    public static List<Integer> allLocZombieDog= new ArrayList<Integer>();
    public List<String> parseLine(String line) //Bu metod dosyadaki her satirda ki kelimeyi parse eder ve liste olarak döndürür.
    {
        List<String> list = new ArrayList<String>();
        String space= " ";
        String [] strarr = line.split(space);
        for(int i=0;i<strarr.length;i++)
        {
            list.add(strarr[i]);
        }
        
        return list;
    }
    public void findvalueLoc(String key,String action,String name) //Bu metod karakterin lokasyonlarını static listeye atar.
    {
        int value =0;
        int index =0;
        for(int i=0;i<allLine.size();i++){
            value =0;
            if(parseLine(allLine.get(i)).contains(action)&&parseLine(allLine.get(i)).contains(name))
            {
                index = parseLine(allLine.get(i)).indexOf(key);
            
                value = Integer.parseInt(parseLine(allLine.get(i)).get(index+1));
                if(null != name)switch (name) {
                    case "Bug":
                        allLocBug.add(value);
                        break;
                    case "Lion":
                        allLocLion.add(value);
                        break;
                    case "Zombie":
                        allLocZombie.add(value);
                        break;
                    case "ZombieDog":
                        allLocZombieDog.add(value);
                        break;
                    case "Mutant":
                        allLocMutant.add(value);
                        break;
                    default:
                        break;
                }
            }
        }
    }
    public int findvalue(String key,String action,String name)//Bu metod karakterin diğer özelliklerini döndürür.
    {
        int value =0;
        int index =0;
        
        for(int i=0;i<allLine.size();i++){
            if(parseLine(allLine.get(i)).contains(action)&&parseLine(allLine.get(i)).contains(name))
            {
                index = parseLine(allLine.get(i)).indexOf(key);
                value = Integer.parseInt(parseLine(allLine.get(i)).get(index+1));           
            }           
        }
        return value;
    }
    public void readFile()//Bu metod kullanıcıdan dosyayı alır ve bütün satırları bir static listeye atar.
    {     
       BufferedReader reader;
        try 
        {
            Scanner inputObj = new Scanner(System.in);
            System.out.println("Please specify txt path for input");
            String pathtxt = inputObj.nextLine();
            //String pathtxt = "C:\\Users\\Tugba.Ozturk\\Desktop\\input.txt";
            reader = new BufferedReader(new FileReader(pathtxt));
            String line = reader.readLine();
            
            while (line != null) {
                allLine.add(line);
                line = reader.readLine();
            }
	    reader.close();
       
        } 
        catch (Exception e) 
        {
            System.out.println("An error occurred.");
            e.printStackTrace();
        } 
   }
}
